import java.util.*;

public class Main {
  public static void main(String[] args) {

    //Itinerary object to use the class's methods
    Itinerary i = new Itinerary();

    //Scanners for integers and strings
    Scanner isc = new Scanner(System.in);
    Scanner ssc = new Scanner(System.in);
    
    //Introduction
    System.out.println("Welcome to the Travel Itinerary Planner!");
    //Menu system that allows for repeatable options
    while(true){
      System.out.println("What would like to do?\n1. Add a city\n2. Delete a city\n3. View Itinerary\n4. Exit");
      int choice = isc.nextInt();

      //Adds a city to the linked list then sorts the list
      if(choice==1){
        while(true){
          City c = new City();
          System.out.println("What is the name of the city?");
          c.nameCity(ssc.nextLine());
          System.out.println("How many days do you plan to stay?");
          c.setTime(isc.nextInt());
          System.out.println("How many visits do you plan to take?");
          c.setVisits(isc.nextInt());
          System.out.println("What is the latitude?");
          c.setX(isc.nextInt());
          System.out.println("What is the longitude?");
          c.setY(isc.nextInt());
          System.out.println("Is this correct?\n" + c.shortString() + "\n1. Yes  2. No");
          int choice1 = isc.nextInt();
          if(choice1==1){
            i.addCity(c);
            break;
          }
        }
        i.sortCity();
      }

      //Deletes a city from the list and resorts it
      if(choice==2){
        System.out.println("What city would you like to delete?");
        String cName = ssc.nextLine();
        i.deleteCity(cName);
        i.sortCity();
      }

      //Prints the sorted list as long as it's not empty
      if(choice==3){
        if(i.isCity()){
          System.out.println(i.showList());
        }
        else{
          System.out.println("There are no cities in the itinerary");
        }
      }
      
      //Ends the program
      if(choice==4){
        break;
      }

    }
  }
}