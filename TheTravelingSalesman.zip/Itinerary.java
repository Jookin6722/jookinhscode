import java.util.*;

public class Itinerary{

  LinkedList<City> list=new LinkedList<City>();

  //Adds a city to the ArrayList
  public void addCity(City c){
    list.add(c);
  }

  //Deletes a city from the ArrayList if found
  //Otherwise prompts user that no city was found
  public void deleteCity(String s){
    for(int i=0; i<list.size(); i++){
      if(list.get(i).getCity().equals(s)){
        list.remove(i);
        System.out.println("City deleted");
      }
    }
  }

  //Finds the hypotenuse between two points
  public double getHyp(int a, int a2, int b, int b2){
    double c = Math.sqrt(Math.pow(Math.abs(a-a2), 2) + Math.pow(Math.abs(b-b2), 2));
    return c;
  }

  //find a way to add the last city to the list within the loop
  public void sortCity(){
    if(list.size()>1){
      int counter=0;
      for(int j=0; j<list.size(); j++){
        double least=Integer.MAX_VALUE;
        for(int i = j; i < list.size(); i++){
          double hyp = getHyp(list.get(j).getX(), list.get(i).getX(), list.get(j).getY(), list.get(i).getY());
          if(hyp<least && hyp!=0){
            least = hyp;
            counter = i;
          }
        }
        list.add(j, list.remove(counter));
      } 
      list.add(0, list.remove(list.size()-1));
    }
    else;
  }

  //Method to check whether the user has added any cities to the list
  public boolean isCity(){
    if(list.size()>0)
      return true;
    else 
      return false;
  }

  //A toString method to output the sorted itinerary
  public String showList(){
    String itinerary = "";
    for(int i=0; i < list.size(); i++){
      itinerary = itinerary + "City " + (i+1) + "\n" + list.get(i).toString() + "\n";
    }
    return itinerary;
  }

}