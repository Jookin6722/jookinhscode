public class City{

  private String cityName;
  private int visits;
  private int time;
  private int xaxis;
  private int yaxis; 

  //Constructors
  public City(){
    cityName = "London";
    visits = 1;
    time = 1;
    xaxis = 50;
    yaxis = 200;
  }

  public City(String c, int v, int t, int x, int y){
    cityName = c;
    visits = v;
    time = t;
    xaxis = x;
    yaxis = y;
  }

  //Accessors
  public String getCity(){
    return cityName;
  }

  public int getVisits(){
    return visits;
  }

  public int getTime(){
    return time;
  }

  public int getX(){
    return xaxis;
  }

  public int getY(){
    return yaxis;
  }

  //Modifiers
  public void nameCity(String s){
    cityName = s;
  }

  public void setVisits(int i){
    visits = i;
  }

  public void setTime(int i){
    time = i;
  }

  public void setX(int i){
    xaxis = i;
  }

  public void setY(int i){
    yaxis = i;
  }

  //ToStrings
  public String toString(){
    return "Location: " + cityName + "\nTotal Visits: " + visits + "\nTime Stayed: " + time + "\nCoordinates: (" + xaxis + ", " + yaxis + ")\n";
  }

  public String shortString(){
    return "Location: " + cityName + "\nLatitude: " + xaxis + "\nLongitude: " + yaxis;
  }
}