import discord
import random
import asyncio
from discord.ext import commands
Intents = discord.Intents.default()
Intents.members = True
runit = False

client = commands.Bot(command_prefix = '!', intents = Intents)

funny_emojis = [ #https://unicode.org/emoji/charts/emoji-list.html#1fae0
	"\U0001F601", #grinning face with big eyes
	"\U0001F923", #rolling on the floor laughing
	"\U0001F609", #winking face ;)
	"\U0001F60A", #smiling face with smiling eyes
	"\U0001F618", #face blowing a kiss
	"\U0001F346", #Eggplant
  "\U0001F62D", #Loudly Crying Face
	"\U0001F914" #shushing face
  "\U0001F63C" #smirk cat
]

@client.event
async def on_ready():
  print("Bot is ready")

@client.command() 
# !remind [amount] [unit] [message] | Sends a message to the user after a certain amount of time.
async def remind(ctx, time: int, unit, *, msg):
  if unit == "s":
    time *= 1
    await asyncio.sleep(time)
    await ctx.send(ctx.author.mention + " " + msg)
  elif unit == "m":
    time *= 60
    await asyncio.sleep(time)
    await ctx.send(ctx.author.mention + " " + msg)
  elif unit == "h":
    time *= 3600
    await asyncio.sleep(time)
    await ctx.send(ctx.author.mention + " " + msg)
  elif unit == "d":
    time *= 86400
    await asyncio.sleep(time)
    await ctx.send(ctx.author.mention + " " + msg)
  else:
    await asyncio.sleep(time)
    await ctx.send(ctx.author.mention + " " + unit + " " + msg)

@client.command() 
# !rremind [message] | Sends a message to a random user after a random amount of time between 1 and 60 seconds.
async def rremind(ctx, *, msg):
	time = random.randint(1, 60) #change 60 to 86400 once on a server
	memberList = list(client.get_all_members())
	ranMember = memberList[random.randint(0, len(memberList) - 1)]
	mentionID = ranMember.id
	mentionMem = client.get_user(mentionID)
	await asyncio.sleep(time)
	await ctx.send(mentionMem.mention + " " + msg)

@client.command() 
# !nick [@user] [reason] | Nicknames a user.
async def nick(ctx, member: discord.Member, *, name):
  await member.edit(nick = name)

@client.command() 
# !kick [@user] [reason] | Kicks a user.
async def kick(ctx, member: discord.Member, *, reason = None):
  await member.kick(reason = reason)

@client.command() 
# !ban [@user] [reason] | Bans a user.
async def ban(ctx, member: discord.Member, *, reason = None):
  await member.ban(reason = reason)

@client.command(aliases=['clear', 'remove']) 
# !purge [# of messages to remove] | Clears a certain number of previous messages.
async def purge(ctx, amt:int):
  await ctx.channel.purge(limit=amt+1)

@client.command() 
# !bothelp | Lists all the commands and how they're used.
async def bothelp(ctx):
  await ctx.send("```!remind [amount] [unit] [message] \nSends a message to the user after a certain amount of time.\n\n!rremind [message] \nSends a message to a random user after a random amount of time between 1 and 60 seconds.\n\n!nick [@user] [reason] \nNicknames a user.\n\n!kick [@user] [reason] \nKicks a user.\n\n!ban [@user] [reason] \nBans a user.\n\n!purge [# of messages to remove] \nClears a certain number of previous messages.\n\n!emote \nSends a random emote into the chat.\n\n!explode \nSpam pings a user until the command is run again.\n\n!cflip \nFlips a coin.```")

@client.command() 
# !emote | Sends a random emote into the chat.
async def emote(ctx):
  await ctx.send(random.choice(funny_emojis))

@client.command()
# !explode | Spam pings a user until the command is run again.
async def explode(ctx, member: discord.Member):
	global runit
	if runit:
		runit = False
	else:
		runit = True
	while runit:
		await asyncio.sleep(0.5)
		await ctx.send(member.mention)

@client.command(aliases=['cf', 'coinflip'])
# !cflip | Flips a coin. 
async def cflip(ctx):
	result = random.randint(0, 1)
	if result == 0:
		await ctx.send("The coin is... heads!")
	else:
		await ctx.send("The coin is... tails!")

client.run('ODkwMzA3NzE1MDgyMTEzMDQ0.YUt5rA.7oSXNbXTUHBHimtdCDN-sePec6s')