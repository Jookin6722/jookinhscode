import spotipy
#import random
#import numpy as np
from spotipy.oauth2 import SpotifyPKCE
#import requests  # to get image from the web
#import shutil  # to save it locally
# import json
import os
# import spotipy.util as util
# import webbrowser


scope = 'playlist-modify-public playlist-modify-private user-top-read ' \
        'user-read-recently-played user-read-currently-playing ugc-image-upload'
client_id = 'ab544d4cdd5c4c9bb5c5ac1df833c8ab'
client_secret = 'dc61b038ace343fcb3d15401419eb8dd'
redirect_uri = 'http://127.0.0.1:8080/'
username = ''

token = SpotifyPKCE(client_id=client_id, redirect_uri=redirect_uri, scope=scope, username=username)
sp = spotipy.Spotify(auth_manager=token)
user = sp.current_user()

sp.user_playlist_create(user, 'test_playlist', public=True)