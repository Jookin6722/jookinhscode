import java.util.*;

class Player{
	
	private int victory;
	private int money;
	public int deck;
	
	ArrayList<Cards> hand = new ArrayList<Cards>();
	ArrayList<Cards> discard = new ArrayList<Cards>();
	Stack<Cards> pile = new Stack<Cards>();
	
	Stack<Cards> bronze = new Stack<Cards>(); //60
	Stack<Cards> silver = new Stack<Cards>(); //40
	Stack<Cards> gold = new Stack<Cards>(); //30
	Stack<Cards> bureaucrat = new Stack<Cards>();
	Stack<Cards> cellar = new Stack<Cards>();
	Stack<Cards> festival = new Stack<Cards>();
	Stack<Cards> library = new Stack<Cards>();
	Stack<Cards> market = new Stack<Cards>();
	Stack<Cards> remodel = new Stack<Cards>();
	Stack<Cards> smithy = new Stack<Cards>();
	Stack<Cards> throneroom = new Stack<Cards>();
	Stack<Cards> village = new Stack<Cards>();
	Stack<Cards> woodcutter = new Stack<Cards>();
	Stack<Cards> estate = new Stack<Cards>(); //24
	Stack<Cards> duchy = new Stack<Cards>(); //12
	Stack<Cards> province = new Stack<Cards>(); //12
	
	public Player(){

		victory = 3;
		money = 7;
		deck = 10;

	}

	public Player(int v, int m, int d){

		victory = v;
		money = m;
		deck = d;

	}

	//Adds all cards to the stacks
	public void addCards(){
		
		for(int i = 0; i < 60; i++){
			bronze.add(new Cards("Bronze"));
		}
		for(int i = 0; i < 40; i++){
			silver.add(new Cards("Silver"));
		}
		for(int i = 0; i < 30; i++){
			gold.add(new Cards("Gold"));
		}
		for(int i = 0; i < 24; i++){
			estate.add(new Cards("Estate"));
		}
		for(int i = 0; i < 12; i++){
			duchy.add(new Cards("Duchy"));
		}
		for(int i = 0; i < 12; i++){
			province.add(new Cards("Province"));
		}
		for(int i = 0; i < 8; i++){
			bureaucrat.add(new Cards("Bureaucrat"));
		}
		for(int i = 0; i < 8; i++){
			cellar.add(new Cards("Cellar"));
		}
		for(int i = 0; i < 8; i++){
			festival.add(new Cards("Festival"));
		}
		for(int i = 0; i < 8; i++){
			library.add(new Cards("Library"));
		}
		for(int i = 0; i < 8; i++){
			market.add(new Cards("Market"));
		}
		for(int i = 0; i < 8; i++){
			remodel.add(new Cards("Remodel"));
		}
		for(int i = 0; i < 8; i++){
			smithy.add(new Cards("Smithy"));
		}
		for(int i = 0; i < 8; i++){
			throneroom.add(new Cards("Throne Room"));
		}
		for(int i = 0; i < 8; i++){
			village.add(new Cards("Village"));
		}
		for(int i = 0; i < 8; i++){
			woodcutter.add(new Cards("Woodcutter"));
		}
	}

	//Deck Manipulation
	public void start(){

		addCards();

		for(int i = 0; i < 7; i++){
			pile.push(bronze.pop());
		}
		for(int i = 0; i < 3; i++){
			pile.push(estate.pop());
		}

		shuffle();

	}

	//Size checkers
	public int getHand(){
		return hand.size();
	}

	public int getDiscard(){
		return discard.size();
	}

	public int getStack(){
		return pile.size();
	}

	//Draw cards functions
	public void ndraw(){

		discard();
		for(int i = 0; i < 5; i++){
			condition();
			hand.add(pile.pop());
		}

	}
	
	public void draw(int a){

		for(int i = 0; i < a; i++){
			condition();
			hand.add(pile.pop());
		}

	}

	//Discard hand
	public void discard(){

		for(int i = 0; i < hand.size(); i++){
			discard.add(hand.get(i));
		}
		hand.removeAll(hand);
		
	}

	//Shuffles deck
	public void shuffle(){

		Collections.shuffle(pile);

	}

	//Prints cards in hand
	public void view(){
		
		for(int i = 0; i < hand.size(); i++){
			System.out.println(hand.get(i).getType());
		}
		
	}

	//Condition checker for draw pile size
	public void condition(){
		
		if(pile.size() == 0){
			for(int i = 0; i < discard.size(); i++){
				pile.push(discard.get(i));
			}
			discard.removeAll(discard);
			shuffle();
		}
		
	}

	//Counts money in hand
	public int count(){

		int amount = 0;

		for(int i = 0; i < hand.size(); i++){
			if(hand.get(i).getType().equalsIgnoreCase("Bronze")){
				amount += 1;
			}
			if(hand.get(i).getType().equalsIgnoreCase("Silver")){
				amount += 2;
			}
			if(hand.get(i).getType().equalsIgnoreCase("Gold")){
				amount += 3;
			}
		}
		return amount;
		
	}

	public void discardMoney(int m){

		
	}

	//Condition for money available to use
	public boolean buyCond(int c){

		int a = count();
		if(a < c){
			return false;
		}
		return true;

	}

	public void buyMoney(){

	}

	//Buy Money
	public void buyBronze(){

		if(buyCond(0)){
			if(bronze.size() != 0){
				discard.add(bronze.pop());
				money += 1;
				System.out.println("Bronze bought");
			}
			else
				System.out.println("No Bronzes left");
		}
		else
			System.out.println("Can't afford");

	}

	public void buySilver(){

		if(buyCond(3)){
			if(silver.size() != 0){
				discard.add(silver.pop());
				money += 2;
				System.out.println("Silver bought");
			}
			else
				System.out.println("No Silvers left");
		}
		else
			System.out.println("Can't afford");

	}

	public void buyGold(){

		if(buyCond(6)){
			if(gold.size() != 0){
				discard.add(gold.pop());
				money += 3;
				System.out.println("Gold bought");
			}
			else
				System.out.println("No Golds left");
		}
		else
			System.out.println("Can't afford");

	}

	//Buy Victory
	public void buyEstate(){

		if(buyCond(2)){
			if(estate.size() != 0){
				discard.add(estate.pop());
				victory += 1;
				System.out.println("Estate bought");
			}
			else
				System.out.println("No Estates left");
		}
		else
			System.out.println("Can't afford");

	}

	public void buyDuchy(){

		if(buyCond(5)){
			if(duchy.size() != 0){
				discard.add(duchy.pop());
				victory += 3;
				System.out.println("Duchy bought");
			}
			else
				System.out.println("No Duchies left");
		}
		else
			System.out.println("Can't afford");

	}

	public void buyProvince(){

		if(buyCond(8)){
			if(province.size() != 0){
				discard.add(province.pop());
				victory += 6;
				System.out.println("Province bought");
			}
			else
				System.out.println("No Provinces left");
		}
		else
			System.out.println("Can't afford");

	}

	//Buy Actions
	public void buyBureaucrat(){

		if(buyCond(4)){
			if(bureaucrat.size() != 0){
				discard.add(bureaucrat.pop());
				System.out.println("Bureaucrat bought");
			}
			else
				System.out.println("No Bureaucrats left");
		}
		else
			System.out.println("Can't afford");

	}

	public void buyCellar(){

		if(buyCond(2)){
			if(cellar.size() != 0){
				discard.add(cellar.pop());
				System.out.println("Cellar bought");
			}
			else
				System.out.println("No Cellars left");
		}
		else
			System.out.println("Can't afford");
			
	}

	public void buyFestival(){

		if(buyCond(5)){
			if(festival.size() != 0){
				discard.add(festival.pop());
				System.out.println("Festival bought");
			}
			else
				System.out.println("No Festivals left");
		}
		else
			System.out.println("Can't afford");
			
	}

	public void buyLibrary(){

		if(buyCond(5)){
			if(library.size() != 0){
				discard.add(library.pop());
				System.out.println("Library bought");
			}
			else
				System.out.println("No Libraries left");
		}
		else
			System.out.println("Can't afford");
			
	}

	public void buyMarket(){

		if(buyCond(5)){
			if(market.size() != 0){
				discard.add(market.pop());
				System.out.println("Market bought");
			}
			else
				System.out.println("No Markets left");
		}
		else
			System.out.println("Can't afford");
			
	}

	public void buyRemodel(){

		if(buyCond(4)){
			if(remodel.size() != 0){
				discard.add(remodel.pop());
				System.out.println("Remodel bought");
			}
			else
				System.out.println("No Remodels left");
		}
		else
			System.out.println("Can't afford");
			
	}

	public void buySmithy(){

		if(buyCond(4)){
			if(smithy.size() != 0){
				discard.add(smithy.pop());
				System.out.println("Smithy bought");
			}
			else
				System.out.println("No Smithies left");
		}
		else
			System.out.println("Can't afford");
			
	}

	public void buyThroneRoom(){

		if(buyCond(4)){
			if(throneroom.size() != 0){
				discard.add(throneroom.pop());
				System.out.println("Throne Room bought");
			}
			else
				System.out.println("No Throne Rooms left");
		}
		else
			System.out.println("Can't afford");
			
	}

	public void buyVillage(){

		if(buyCond(3)){
			if(village.size() != 0){
				discard.add(village.pop());
				System.out.println("Village bought");
			}
			else
				System.out.println("No Villages left");
		}
		else
			System.out.println("Can't afford");
			
	}

	public void buyWoodcutter(){

		if(buyCond(3)){
			if(woodcutter.size() != 0){
				discard.add(woodcutter.pop());
				System.out.println("Woodutter bought");
			}
			else
				System.out.println("No Woodcutters left");
		}
		else
			System.out.println("Can't afford");
			
	}




	/*public void winCond(){
		if()
	}*/
}