import java.util.*;

class Cards{

	private String type; 

	public Cards(){
		
		type = "estate";

	}

	public Cards(String t){

		type = t;
		
	}

	public String getType(){
		
		return type;
		
	}
}