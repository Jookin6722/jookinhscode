import java.util.*;

class Main {

	public static void clear(){
		System.out.print("\033[H\033[2J");
		System.out.flush();
	}

  public static void main(String[] args) {
    
		Player p = new Player();

		Scanner isc = new Scanner(System.in);

		System.out.println("Welcome to Dominion");
		p.start();
		
		while(true){

			System.out.println("Cards in hand: " + p.getHand());
			System.out.println("Cards in discard: " + p.getDiscard());
			System.out.println("Cards in deck: " + p.getStack());
			System.out.println("1.Draw Hand\n2.Draw #\n3.View\n4.Shuffle\n5.Discard Hand\n6.Buy Money\n7.Buy Victory\n8.Buy Actions\n9.Play Actions\n10.Break");
			int c = isc.nextInt();

			int money = p.count();
			
			if(c == 1){
				p.ndraw();
			}
			if(c == 2){
				System.out.println("How many cards");
				p.draw(isc.nextInt());
			}
			if(c == 3){
				clear();
				p.view();
			}
			if(c == 4){
				p.shuffle();
			}
			if(c == 5){
				p.discard();
			}
			if(c==6){

				System.out.println("What would you like to buy?\nCurrent Money ("+ money +")\n1. Bronze (0)\n2. Silver (3)\n3. Gold (6)\n4. Back to Selection");
				int x = isc.nextInt();

				if(x == 1){
					p.buyBronze();
				}
				if(x == 2){
					p.buySilver();
					money -= 3;
				}
				if(x == 3){
					p.buyGold();
					money -= 6;
				}
				if(x == 4){
					continue;
				}

			}
			if(c == 7){

				System.out.println("What would you like to buy?\nCurrent Money ("+ money +")\n1. Estate (2)\n2. Duchy (5)\n3. Provice (8)\n4. Back to Selection");
				int x = isc.nextInt();

				if(x == 1){
					p.buyEstate();
					money -= 2;
				}
				if(x == 2){
					p.buyDuchy();
					money -= 5;
				}
				if(x == 3){
					p.buyProvince();
					money -= 8;
				}
				if(x == 4){
					continue;
				}

			}
			if(c == 8){

				System.out.println("What would you like to buy?\nCurrent Money ("+ money +")\n1. Cellar (2)\n2. Woodcutter (3)\n3. Village (3)\n4. Bureaucrat (4)\n5. Throne Room (4)\n6. Remodel (4)\n7. Smithy (4)\n8. Library (5)\n9. Market (5)\n10. Festival (5)\n11. Back to Selection");
				int x = isc.nextInt();

				if(x == 1){
					p.buyCellar();
					money -= 2;
				}
				if(x == 2){
					p.buyWoodcutter();
					money -= 3;
				}
				if(x == 3){
					p.buyVillage();
					money -= 3;
				}
				if(x == 4){
					p.buyBureaucrat();
					money -= 4;
				}
				if(x == 5){
					p.buyThroneRoom();
					money -= 4;
				}
				if(x == 6){
					p.buyRemodel();
					money -= 4;
				}
				if(x == 7){
					p.buySmithy();
					money -= 4;
				}
				if(x == 8){
					p.buyLibrary();
					money -= 5;
				}
				if(x == 9){
					p.buyMarket();
					money -= 5;
				}
				if(x == 10){
					p.buyFestival();
					money -=5;
				}
				if(x == 11){
					continue;
				}

			}
			if(c == 9){

			}
			if(c == 10){
				break;
			}
		}
  }
}