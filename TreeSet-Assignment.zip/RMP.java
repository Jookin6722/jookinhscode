import java.util.*;
import java.io.*;

class RMP{
	
	//Creates a SortedSet from the TreeSet path
	SortedSet<Professor> set = new TreeSet<>();

	//An add method for the set
	public void add(Professor p){
		set.add(p);
	}

	//Delete method for the set
	public void delete(Professor p){
		set.remove(p);
	}

	//Method utilizing the equals method in the Professor class to return true if the inputted professor is the same as a professor and false otherwise
	public boolean search(Professor newp){
		for(Professor p : set) {
			if(p.equals(newp))
				return true;
		}
		return false;
	}

	//Returns a name if the first name separated by a space is the same as a first name already in the set
	public String nsearch(String n){
		String list = "";
		for(Professor p : set) {
			String[] name = p.getName().split(" ", 2);
			if(name[0].equalsIgnoreCase(n))
				list = list + p.toString() + "\n\n";
		}
		return list;
	}

	//Tailset method outputting a temporary set containing values enclosed by the tail
	public void tail(Professor p){
		SortedSet<Professor> temp = new TreeSet<>();
		temp = set.tailSet(p);
		for(Professor pt : temp){
			System.out.println(pt.toString() + "\n");
		}
	}

	//Headset method
	public void head(Professor p){
		SortedSet<Professor> temp = new TreeSet<>();
		temp = set.headSet(p);
		for(Professor pt : temp){
			System.out.println(pt.toString() + "\n");
		}
	}

	//Subset method
	public void sub(Professor p, Professor p2){
		SortedSet<Professor> temp = new TreeSet<>();
		temp = set.subSet(p, p2);
		for(Professor pt : temp){
			System.out.println(pt.toString() + "\n");
		}
	}

	//Print method
	public void print(){
		for(Professor p : set){
			System.out.println(p.toString() + "\n");
		}
	}
}