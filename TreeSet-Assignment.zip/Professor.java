import java.io.*;
import java.util.*;

class Professor implements Comparable<Professor>{

	//Object attributes
	private String name;
	private double rating;
	private String course;

	//Default constructor
	public Professor(){
		name = "Dale Britton";
		rating = 10.00;
		course = "Computer Science";
	}

	//Constructor
	public Professor(String n, double r, String c){
		name = n;
		rating = r;
		course = c;
	}

	//Comparable method for professor ratings
	public int compareTo(Professor p){
		if(this.rating > p.rating)
			return 1;
		if(this.rating < p.rating)
			return -1;
		else
			return 0;
	}

	//Equals method for every professor attribute
	public boolean equals(Professor p){
		if(this.name.equalsIgnoreCase(p.name) && this.rating == p.rating && this.course.equalsIgnoreCase(p.course))
			return true;
		else
			return false;
	}

	//Accessors
	public String getName(){
		return name;
	}

	public double getRating(){
		return rating;
	}

	public String getCourse(){
		return course;
	}

	//ToString method
	public String toString(){
		return "Professor " + name + "\nRating: " + rating + "\nCourse: " + course;
	}
}
