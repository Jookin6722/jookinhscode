import java.util.*;
import java.io.*;
import java.text.DecimalFormat;

class Main {

	//A clear method so there is less on screen
	public static void clear() {  
    System.out.print("\033[H\033[2J");  
    System.out.flush();  
	} 

	//Rounds professor rating to two decimal places
	private static final DecimalFormat df = new DecimalFormat("0.00");

  public static void main(String[] args) {

		Scanner ssc = new Scanner(System.in);
		Scanner isc = new Scanner(System.in);
		Scanner dsc = new Scanner(System.in);

		RMP r = new RMP();

    System.out.println("Welcome to Rate my Professor!");

		//Loop so user can continue to use program
		while(true){
			System.out.println("What would you like to do?\n1. Add a professor\n2. Remove a professor\n3. Print Ratings\n4. Search\n5. Exit");
			int choice = isc.nextInt();

			//Creates a professor using an inputted name and course and a randomly generated rating to the set
			if(choice == 1){
				clear();
				System.out.println("What is the name of the professor?");
				String name = ssc.nextLine();
				System.out.println("What course do they teach?");
				String course = ssc.nextLine();

				double rating = (Math.random()*9)+1;
				String round = df.format(rating);
				double fix = Double.parseDouble(round);

				Professor p = new Professor(name, fix, course);
				r.add(p);

				clear();
				System.out.println("Professor added.\n");
				System.out.println(p.toString() + "\n");
			}

			//Deletes the professor, user has to input exact name, course, and rating, and returns not found otherwise
			if(choice == 2){
				clear();
				r.print();

				System.out.println("What is the name of the professor?");
				String name = ssc.nextLine();
				System.out.println("What rating do they have? (Note: Include 2 decimal places)");
				double rating = dsc.nextDouble();
				System.out.println("What course do they teach?");
				String course = ssc.nextLine();
				Professor p = new Professor(name, rating, course);
				if(r.search(p))
					r.delete(p);

				clear();
				System.out.println("Professor deleted\n");
			}

			//Prints the current list
			if(choice == 3){
				clear();
				r.print();
			}

			//Searches
			//Can search by finding an exact professor, course, rating, finding professors by name, or search by subset methods
			if(choice == 4){
				clear();
				System.out.println("What would you like to do?\n1. Search individual\n2. Search by name\n3. Search by rating");
				int c = isc.nextInt();

				if(c == 1){
					System.out.println("What is the name of the professor?");
					String name = ssc.nextLine();
					System.out.println("What rating do they have? (Note: Include 2 decimal places)");
					double rating = dsc.nextDouble();
					System.out.println("What course do they teach?");
					String course = ssc.nextLine();
					Professor p = new Professor(name, rating, course);
					if(r.search(p)){
						clear();
						System.out.println("Professor found.\n" + p.toString());
					}
					else{
						clear();
						System.out.println("No professor found.\n");
					}
				}

				if(c == 2){
					System.out.println("Enter a name");
					String name = ssc.nextLine();
					
					clear();
					System.out.println(r.nsearch(name));
				}

				if(c == 3){
					System.out.println("How would you like to search by?\n1. TailSet\n2. HeadSet\n3. Subset");
					int c2 = isc.nextInt();
					if(c2 == 1){
						System.out.println("Enter a rating. (Note: Include 2 decimal places)");
						double rating = dsc.nextDouble();
						Professor p = new Professor("Dale Britton", rating, "Comp Sci");
						r.tail(p);
					}
					if(c2 == 2){
						System.out.println("Enter a rating. (Note: Include 2 decimal places)");
						double rating = dsc.nextDouble();
						Professor p = new Professor("Dale Britton", rating, "Comp Sci");
						r.head(p);
					}
					if(c2 == 3){
						System.out.println("Enter the low rating. (Note: Include 2 decimal places)");
						double lrating = dsc.nextDouble();
						Professor lp = new Professor("Dale Britton", lrating, "Comp Sci");

						System.out.println("Enter the high rating. (Note: Include 2 decimal places)");
						double hrating = dsc.nextDouble();
						Professor hp = new Professor("Dale Britton", hrating, "Comp Sci");
						r.sub(lp, hp);
					}
				}
			}
			
			//Ends the program
			if(choice == 5){
				break;
			}
		}
  }
}