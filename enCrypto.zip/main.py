#https://www.tutorialspoint.com/python_pillow/Python_pillow_merging_images.htm
#Asks user for the file name/path and a 
from PIL import ImageDraw, ImageFont, Image, ImageFilter, ImageChops

def watermark():
	im = Image.open(filename)
	im.save(filename)
	width, height = im.size
	draw = ImageDraw.Draw(im)
	watertext = input("What should your watermark say?\n")
	font = ImageFont.truetype('Arial.ttf', 36)
	textwidth, textheight = draw.textsize(watertext, font)
	margin = 10
	x = width - textwidth - margin
	y = height - textheight - margin
	draw.text((x,y), watertext, font=font)
	im.save('final.jpg')

def blur():
	im = Image.open(filename)
	im.save(filename)
	factor = int(input("Enter a number 1 through 20 to select how blurry your image will be: "))
	im.filter(ImageFilter.GaussianBlur(factor)).save("final.jpg")
	
def filter():
	im = Image.open(filename)
	im.save(filename)
	filtered = im.filter(ImageFilter.MaxFilter(5))
	filtered.save('final.jpg')

def flip():
	im = Image.open(filename)
	im.save(filename)
	flip = int(input("Flip\n1. Horizontally\n2. Vertically\n"))
	if flip == 1:
		hflip = im.transpose(Image.FLIP_LEFT_RIGHT)
		hflip.save('final.jpg')
	else:
		vflip = im.transpose(Image.FLIP_TOP_BOTTOM)
		vflip.save('final.jpg')

def invertColors():
	im = Image.open(filename)
	im.save(filename)
	inverted = ImageChops.invert(im)
	inverted.save('final.jpg')

def dencrypt():
	key = int(input("Enter a password\n"))
	file = open(filename, 'rb')
	image = file.read()
	file.close()
	image = bytearray(image)
	for index, values in enumerate(image):
		image[index] = values ^ key
	file = open(filename, 'wb')
	file.write(image)
	file.close()

while True:
	filename = input("What is the name of the file you would like to edit?\n")
	
	c = int(input("Select an action.\nWatermark (1)\nBlur (2)\nFilter (3)\nFlip(4)\nInvert Colors (5)\nEncrypt/Decrypt (6)\nSTOP (7)\n"))
	
	if c == 1:
		watermark()
	elif c == 2:
		blur()
	elif c == 3:
		filter()
	elif c == 4:
		flip()
	elif c == 5:
		invertColors()
	elif c == 6:
		dencrypt()
	else:
		break