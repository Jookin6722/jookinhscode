import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.io.FileNotFoundException;
import java.io.FileReader;

class Main {
  public static void main(String[] args) throws Exception{
    
    Scanner words=new Scanner(System.in); //Creates a scanner for strings
    Scanner numb=new Scanner(System.in); //Creates a scanner for integers
    Map<String, String> dict=new HashMap<String, String>(); //Creates a hashmap 
    ArrayList<String> list=new ArrayList<String>(); //Creates an arraylist 

    String bin=""; //Empty key
    String dec=""; //Empty value

    System.out.println("Welcome to the binary to decimal translator!");
    while(true){ //While loop that continues the process so the user can go back to the menu and make different choices
      System.out.println("What would you like to do?\n1)Add conversion\n2)Save conversion to file\n3)Retrieve a file\n4)Quit");
      int choice=numb.nextInt();
    
      if(choice==1){
        while(true){ //While loop used to go back just in case the user inputs the wrong translation
          System.out.println("What binary would you like to input?"); //Asks for hashmap key
          bin=words.nextLine();

          System.out.println("What does that convert to decimal?"); //Asks for hashmap value
          dec=words.nextLine();

          System.out.println("Is "+bin+", "+dec+" correct?"); //Confirmation
          String answer=words.nextLine();

          if(answer.equalsIgnoreCase("Yes")){ //Puts values into hashmap if confirmed
            dict.put(bin,dec);
            break; //Ends option 1    
          }
        }
      }
    
      if(choice==2){
        System.out.println("Would you like to save the previous entry? ("+bin+", "+dict.get(bin)+")\nYes   No"); //User Confirmation
        String ans=words.nextLine();

        if(ans.equalsIgnoreCase("Yes")){ //If confirmed it creates a fileWriter and inputs the key and value from the hashmap into a new file with the key as the file name
          String str = bin + " " + dict.get(bin);
        try{
          FileWriter fw=new FileWriter(""+bin+".txt");
          fw.flush();
          for(int i=0; i<str.length(); i++)
            fw.write(str.charAt(i));
          fw.close();
        }catch(Exception e){
          e.getStackTrace();
        }
        list.add(bin); //Adds the added key value to an ArrayList
        System.out.println("Save Confirmed");
        }
      }

      if(choice==3){
        while(true){ //While loop used just in case the user adds a non-suitable entry name so they can try again
          System.out.println(list); //Shows available entries
          System.out.println("Which entry would you like to see?");
          String file=words.nextLine();

          boolean there=false; //Determines whether the user input is a valid entry by setting a boolean value true or false
          for(int i=0; i<list.size(); i++){
            if(file.equals(list.get(i))){
              there=true;
              break;
            }
            else
              there=false;
          }

          if(there==false) //If entry value doesn't exist it asks to enter a valid one
            System.out.println("Please enter an entry that exists");
          else{ //Creates a fileReader and retrieves the entry
            FileReader fr =new FileReader(""+file+".txt");
            int i;
            while ((i=fr.read()) != -1)
              System.out.print((char) i);
            System.out.println("\n");
            break;
          }
        }
      }

      if(choice==4){ //Ends the program
        break;
      }
    }
  }
}