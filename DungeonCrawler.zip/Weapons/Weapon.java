class Weapon{

  private String name;
  private String desc;
  private String edesc;
  private String rarity;
  private int baseATK;
  private boolean effect;
  private boolean magic;
  private int gvalue;
  private int weaponID;

  public Weapon(){
    name = "Basic Sword";
    desc = "As basic as it gets.";
    edesc = "None";
    rarity = "Common";
    baseATK = 5;
    effect = false;
    magic = false;
    gvalue = 5;
    weaponID = 1;
  }

  public Weapon(String n, String d, String ed, String r, int ba, boolean e, boolean m, int gv, int id){
    name = n;
    desc = d;
    edesc = ed;
    rarity = r;
    baseATK = ba;
    effect = e;
    magic = m; 
    gvalue = gv;
    weaponID = id;
  }
}
