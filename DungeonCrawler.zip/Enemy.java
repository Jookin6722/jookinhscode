import java.util.*;

class Enemy{

  private String name;
  private int HP;
  private int ATK;
  private int SPD;
  private boolean effect;
  private String ename;

  private ArrayList<Enemy> elist = new ArrayList<Enemy>(){{
    add(new Enemy("Slime", 75, 15, 5, false, "None"));
    add(new Enemy("Spider", 100, 20, 15, true, "Slow"));
    add(new Enemy("Zombie", 100, 20, 10, false, "None"));
    add(new Enemy("Wolf", 125, 30, 20, false, "None"));
    add(new Enemy("Stefan", 5000, 100, 100, true, "Meow"));
  }};


  public Enemy(){
    name = "Slime";
    HP = 75;
    ATK = 15; 
    SPD = 5;
    effect = false;
    ename = "None";
  }

  public Enemy(String n, int h, int a, int s, boolean e, String en){
    name = n;
    HP = h;
    ATK = a;
    SPD = s;
    effect = e;
    ename = en;
  }

  public ArrayList<Enemy> getList(){
    return elist;
  }

  public String getName(){
    return name;
  }

  public int getHP(){
    return HP;
  }
  
  public int getSpd(){
    return SPD;
  }

  public String getEff(){
    return ename;
  }

  public double attack(){
    return ATK * (Math.random() + 1);
  }

  public void loseHP(int h){
    HP -= h;
  }

  public static void main(String[] args) {

  }
}