import java.util.*;

class Events{
  
  Scanner sc = new Scanner(System.in);
  Map m = new Map();

  public void queue(int i, Player p){
    int r = (int)((Math.random()*100)+1);
    if(r<=1){
      queueSkip();
    }
    else if(r>1 && r<=7){
      queueShop();
    }
    else if(r>7 && r<=17){
      queueBattle(i, p);
    }
    else if(r>17 && r<=23){
      queueTrap();
    }
    else if(r>23 && r<=30){
      queueItem();
    }
    else{
    }
  }

  public void queueBattle(int i, Player p){
    Enemy e = new Enemy();
    Player u = p;
    m.clear();
    if(i <= 3){
      int er = (int)Math.random()*2;
      Enemy one = e.getList().get(er);
      while(one.getHP()>0){
        System.out.println("You've encountered a " + e.getName() + "\n1. Attack\n2. Run");
        if(sc.nextLine().equals("1")){
          if(u.getSPD()>one.getSpd()){
            one.loseHP(p.getATK());
            p.loseHP(one.attack());
          }
          else{
            p.loseHP(one.attack());
            one.loseHP(p.getATK());
          }
        }
        else{
          int c = (int)Math.random()*1;
          if(c==0)
            break;
          else;
        }
      }
    }
    if(i>3 && i <= 10){
      int er = (int)Math.random()*3;
      Enemy one = e.getList().get(er);
      while(one.getHP()>0){
        System.out.println("You've encountered a " + e.getName() + "\n1. Attack\n2. Run");
        if(sc.nextLine().equals("1")){
          if(u.getSPD()>one.getSpd()){
            one.loseHP(p.getATK());
            p.loseHP(one.attack());
          }
          else{
            p.loseHP(one.attack());
            one.loseHP(p.getATK());
          }
        }
        else{
          int c = (int)Math.random()*1;
          if(c==0)
            break;
          else;
        }
      }
    }
    if(i <= 3){
      int er = (int)Math.random()*4;
      Enemy one = e.getList().get(er);
      while(one.getHP()>0){
        System.out.println("You've encountered a " + e.getName() + "\n1. Attack\n2. Run");
        if(sc.nextLine().equals("1")){
          if(u.getSPD()>one.getSpd()){
            one.loseHP(p.getATK());
            p.loseHP(one.attack());
          }
          else{
            p.loseHP(one.attack());
            one.loseHP(p.getATK());
          }
        }
        else{
          int c = (int)Math.random()*1;
          if(c==0)
            break;
          else;
        }
      }
    }
  }

  public void queueSkip(){
    
  }

  public void queueTrap(){

  }

  public void queueShop(){

  }

  public void queueItem(){

  }
  
  public void tAnim(){
    System.out.println("*******************************************************************************\n          |                   |                  |                     |\n _________|________________.=``_;=.______________|_____________________|_______\n|                   |  ,-`_,=``     ``=.|                  |\n|___________________|__`=._o``-._        ``=.______________|___________________\n          |                ``=._o``=._      _``=._                     |\n _________|_____________________:=._o `=._.`_.-=`'`=.__________________|_______\n|                   |    __.--` , ; ``=._o.` ,-```-._ `.   |\n|___________________|_._`  ,. .` ` `` ,  ``-._`-._   `. '__|___________________\n          |           |o``=._` , `` `; .`. ,  `-._`-._; ;              |\n _________|___________| ;`-.o``=._; .` ` '`.`` . `-._ /_______________|_______\n|                   | |o;    ``-.o``=._``  '` ` ,__.--o;   |\n|___________________|_| ;     (#) `-.o ``=.`_.--`_o.-; ;___|___________________\n____/______/______/___|o;._    `      ``.o|o_.--`    ;o;____/______/______/____\n/______/______/______/_`=._o--._        ; | ;        ; ;/______/______/______/_\n____/______/______/______/__`=._o--._   ;o|o;     _._;o;____/______/______/____\n/______/______/______/______/____`=._o._; | ;_.--`o.--`_/______/______/______/_\n____/______/______/______/______/_____`=.o|o_.--``___/______/______/______/____\n/______/______/______/______/______/______/______/______/______/______/______/_\n*******************************************************************************");
  }
}

