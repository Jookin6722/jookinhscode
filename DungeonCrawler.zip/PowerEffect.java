class PowerEffect{
  
}