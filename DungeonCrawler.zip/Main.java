import java.util.*;

class Main {
  public static void main(String[] args) {

    Map m = new Map();
    Player p = new Player();
    Events e = new Events();
    Scanner sc = new Scanner(System.in);
    Scanner ic = new Scanner(System.in);

    System.out.println("Here starts the journey of... \nEnter your name");
    p.nameChange(sc.nextLine());
    m.clear();
    
    //System.out.println(p.showStats());
    for(int i=1; i<=20; i++){
      m.makeLVL(i);
      m.setRoom();
      while(!m.inExit()){
        m.guide();
        System.out.println("Floor " + i);
        System.out.println(m.printUI());
        m.move(sc.nextLine(), p);
        //e.queue(i, p);
      }
    }
  }
}