import java.util.*;
import java.lang.Thread;

class Map extends Thread{

  private String[][] floor;
  private int rrow;
  private int rcol;
  private int rerow;
  private int recol;

  public void makeLVL(int l){
    if(l <= 3){
      String[][] room = new String[7][13];
      for(int x=0; x<7; x++){
        for(int y=0; y<13; y++){
          room[x][y] = "#";
        }
      }
      floor = room;
    }
    else if(l <= 10){
      String[][] room = new String[9][19];
      for(int x=0; x<9; x++){
        for(int y=0; y<19; y++){
          room[x][y] = "#";
        }
      }
      floor = room;
    }
    else{
      String[][] room = new String[12][25];
      for(int x=0; x<12; x++){
        for(int y=0; y<25; y++){
          room[x][y] = "#";
        }
      }
      floor = room;
    }
  }

  public void setRoom(){
    rrow = (int)(Math.random() * floor.length);
    rcol = (int)((Math.random() * floor[0].length));

    if(rcol >= floor.length)
      rcol -= 2;

    floor[rrow][rcol] = "[";
    floor[rrow][rcol+1] = "0";
    floor[rrow][rcol+2] = "]";

    rerow = (int)(Math.random() * floor.length);
    recol = (int)((Math.random() * floor[0].length));

    if(recol >= floor.length) 
      recol -= 2;

    while((rrow == rerow && rcol == recol) || (rrow == rerow && (Math.abs(rcol - recol) <= 1)) || (rrow == rerow && (Math.abs((rcol+2) - recol) <=1))){
      rerow = (int)(Math.random() * floor.length);
      recol = (int)((Math.random() * floor[0].length));
    }   
  }

  public int[] getCoord(){
    int[] coord = new int[2];

    for(int x=0; x<floor.length; x++){
      for(int y=0; y<floor[0].length; y++){
        if(floor[x][y].equals("0")){
          coord[0] = x;
          coord[1] = y;
        }
      }
    }
    return coord;
  }
  
  public void findDoor(){
    int[] coord = getCoord();
    
    if((Math.abs(coord[0] - rerow)<=1) && ((Math.abs(coord[1] - (recol +2))<=1) || (Math.abs(coord[1] - recol)<=1))){
      floor[rerow][recol] = "{";
      floor[rerow][recol+2] = "}";
    }
  }
  
  public boolean inExit(){
    int[] coord = getCoord();

    if((coord[0] == rerow && coord[1] == recol) || (coord[0] == rerow && coord[1] == recol + 1) || (coord[0] == rerow && coord[1] == recol + 2)){
      return true;
    }
    return false;
  }

  public String printRoom(){
    String map = "";
    for(int x=0; x<floor.length; x++){
      for(int y=0; y<floor[0].length; y++){
        map += floor[x][y];
      }
      map += "\n";
    }
    return map;
  }

  public String printUI(){
    Player p = new Player();
    String UI = p.HPbar() + "        💰 " + p.getGold() + "G\n" + p.MPbar() + "\n\n" + printRoom() + "\n       W ^              ---------    ---------\n         |              | ITEMS |    | STATS |\nA <--         --> S     |   Z   |    |   X   |\n         |              ---------    ---------\n       D v                                    ";
    return UI;
  }

  public void move(String c, Player p){
    int coord[] = getCoord();

    findDoor();

    if(c.equalsIgnoreCase("w")){
      if((coord[0]-1) < 0){
        clear();
        System.out.println("You can't move there");
      }
      else{
        clear();
        floor[coord[0]-1][coord[1]] = "0";
        floor[coord[0]][coord[1]] = "X";
      }
    }
    if(c.equalsIgnoreCase("a")){
      if((coord[1]-1) < 0){
        clear();
        System.out.println("You can't move there");
      }
      else{
        clear();
        floor[coord[0]][coord[1]-1] = "0";
        floor[coord[0]][coord[1]] = "X";
      }
    }
    if(c.equalsIgnoreCase("s")){
      if((coord[0]+1) > floor.length-1){
        clear();
        System.out.println("You can't move there");
      }
      else{
        clear();
        floor[coord[0]+1][coord[1]] = "0";
        floor[coord[0]][coord[1]] = "X";
      }
    }
    if(c.equalsIgnoreCase("d")){
      if((coord[1]+1) > floor[0].length-1){
        clear();
        System.out.println("You can't move there");
      }
      else{
        clear();
        floor[coord[0]][coord[1]+1] = "0";
        floor[coord[0]][coord[1]] = "X";
      }
    }
    if(c.equalsIgnoreCase("z")){
      System.out.println("");
    }
    if(c.equalsIgnoreCase("x")){
      clear();
      System.out.println(p.showStats());
      try{
        Thread.sleep(3000);
      }
      catch(Exception e){
        System.out.println(e);
      }
      clear();
    }
  }

  public static void clear() {  
    System.out.print("\033[H\033[2J");  
    System.out.flush();  
  }

  public void guide(){ 
    int[] coord = getCoord();

    System.out.println("Entrance coordinates " + rrow + " " + rcol + "\nExit coordinates " + rerow + " " + recol + "\nPlayer coordinates " + coord[0] + " " + coord[1]);  
  }
}