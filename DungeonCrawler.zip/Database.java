import java.util.*;
import java.io.*;

class Database{
  public static void main(String[] args) {
    ArrayList<Weapon> wlist = new ArrayList<Weapon>();

    
  }
}