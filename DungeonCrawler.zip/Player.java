class Player{

  private String name;
  private double HP;
  private double currentHP;
  private double MP;
  private double currentMP;
  private int ATK;
  private int mATK;
  private double DEF;
  private double INT;
  private int SPD;
  private int LVL;
  private int XP;
  private int XPcap;
  private int gold;

  //Constructors
  //Starting Player
  public Player(){
    name = "Player";
    currentHP = 100;
    HP = 100;
    currentMP = 50;
    MP = 50;
    ATK = 20;
    mATK = 10;
    DEF = 0;
    INT = 0.1;
    SPD = 10;
    LVL = 1;
    XP = 0;
    XPcap = 100;
    gold = 0;
  }

  //Custom Player
  public Player(String n, int ch, int h, int cm, int m, int a, int ma, double d, double i, int s, int l, int x, int xc, int g){
    name = n;
    currentHP = ch;
    HP = h;
    currentMP = cm;
    MP = m;
    ATK = a;
    mATK = ma;
    DEF = d;
    INT = i;
    SPD = s;
    LVL = l;
    XP = x;
    XPcap = xc;
    gold = g;
  }

  //Accessors
  public String getName(){
    return name;
  }

  public double getHP(){
    return HP;
  }

  public double getMP(){
    return MP;
  }

  public int getATK(){
    return ATK;
  }

  public int getmATK(){
    return mATK;
  }

  public double getDEF(){
    return DEF;
  }

  public double getINT(){
    return INT;
  }

  public int getSPD(){
    return SPD;
  }

  public int getLVL(){
    return LVL;
  }

  public int getXP(){
    return XP;
  }

  public int getCap(){
    return XPcap;
  }

  public int getGold(){
    return gold;
  }

  public String showStats(){
    return name + "'s Stats\nLVL " + LVL + "\nXP " + XP + "/" + XPcap + "\n" + HPbar() + "\n" + MPbar() + "\nATK: " + ATK + "\nDEF: " + (DEF * 10) + "\nINT " + (INT * 10) + "\nSPD: " + SPD + "\nGold: " + gold + "💰";
  }

  public String HPbar(){
    String bar = "";
    double percent = (currentHP / HP) * 100;
    float full = Math.round(percent / 10.0);
    for(int i=0; i<10; i++){
      if(i < full)
        bar += "◼";
      else
        bar += "◻";
    }
    return "HP " + bar + " " + (int)currentHP + "/" + (int)HP;
  }

  public String MPbar(){
    String bar = "";
    double percent = (currentMP / MP) * 100;
    float full = Math.round(percent / 10.0);
    for(int i=0; i<10; i++){
      if(i < full)
        bar += "◼";
      else
        bar += "◻";
    }
    return "MP " + bar + " " + (int)currentMP + "/" + (int)MP;
  }
  
  //Modifiers
  public void nameChange(String n){
    name = n;
  }

  public void addHP(int h){
    HP += h;
    currentHP += h;
  }

  public void loseHP(double h){
    currentHP -= h;
  }

  public void addMP(int m){
    MP += m;
    currentMP += m;
  }

  public void useMP(int m){
    currentMP -= m;
  }
  
  public void addATK(int a){
    ATK += a;
  }

  public void addmATK(int ma){
    mATK += ma;
  }

  public void addDEF(double d){
    DEF += d;
    HP += HP * DEF;
  }

  public void andINT(double i){
    INT += i;
    MP += INT * 100;
    mATK += INT * (ATK/4);
  }

  public void addSPD(int s){
    SPD += s;
  }

  public void addXP(int x){
    XP += x;
  }

  public void addGold(int g){
    gold += g;
  }

  public void LVLuP(){
    LVL += 1;
    HP += HP * (LVL * 0.2);
    MP += MP * (LVL * 0.2);
    SPD += 10;
    XP = 0;
    XPcap += 50;
    if(currentHP!=HP)
      currentHP += (HP - currentHP) * 0.2;
    if(currentMP!=MP)
      currentMP += (MP - currentMP) * 0.2;
    if(LVL >= 5){
      INT += 0.5;
      DEF += 0.5;
    }
  }
  
}