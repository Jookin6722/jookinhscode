# 12/6/2021
# Image to ASCII
# Jakin, Sam, Moid, Stefant
import PIL
import numpy as np

FILENAME = "IMGFiles//" + input("Enter the file name you would like to open: ")
compressFactor = int(input("Enter the compression factor from 1 to 10: "))
RotateAmt = int(input("How many degrees would you like to rotate the picture. Enter 0 for no rotation: \n"))
grey = input("What grayscale would you like?:\n1. 64 bit\n2. 16 bit\n")

from PIL import Image
# 64 levels of gray

gscale1 = "$@B%8WM#*oahkbdpqwZO0QLCJUYXzcvunxrjft/\|(){}[]?-+~<>i!lI:,^`'. "

# 16 levels of gray
gscale2 = '@B%M#*c|+=~-;:. '

D = 16
gscale = ""

if grey == "1":
	gscale = gscale1
	D = 4
if grey == "2": 
	gscale = gscale2
	D = 16

with Image.open(FILENAME) as im: #(520, 512)

	#Crops the image
	width = im.size[0]-(im.size[0]%compressFactor)
	height = im.size[1]-(im.size[1]%compressFactor)
	im = im.crop((0, 0, width, height))

	#Saves the cropped image
	im = im.rotate(RotateAmt)
	im.save('output.png')

	#Stores RGB values into an array
	imageseq = im.getdata()
	imageArray = np.array(imageseq)
	print("Original pixels: ")
	print(len(imageArray))

	#Gets grayscale value for each pixel in the array
	gary = []
	i = 0
	for array in imageArray:
		if i % compressFactor == 0:
			Grayscale = array[0]*.299 + array[1]*.587 + array[2]*.114
			gary.append(int(Grayscale/D))
		i = i + 1

	print("Compressed pixels: ")
	print(len(gary))

file = open("output.txt", "w")
file.write("")
file.close()

rfile = open("output.txt", "a")
p=0
newPix = ""
for y in range(int(height/compressFactor)):
	for x in range(int(width/compressFactor)):
		newPix = newPix + gscale[int(gary[int(p)])]
		p=p+1
	newPix = newPix + "\n"
	p=p+(width/compressFactor)*(compressFactor-1)
rfile.write(newPix)

print(len(newPix))
print("Done")

#for y in range(int(height/2)):
	#rfile.write("\n")
	#if y % 2 == 0:
		#for x in range(int(width/2)):
			#newPix = gscale1[int(gary[x + (x*y)])]
			#rfile.write(newPix)